const express = require('express');
const bodyParser = require('body-parser');

const app = express();


app.use(bodyParser.json());


app.get('/', (req, res) => {
  res.send('Servidor Express rodando! Use as rotas /soma, /subtracao, /multiplicacao ou /divisao.');
});


function soma(a, b) {
  return a + b;
}

function subtracao(a, b) {
  return a - b;
}

function multiplicacao(a, b) {
  return a * b;
}

function divisao(a, b) {
  if (b === 0) return 'Erro: divisão por zero não é permitida';
  return a / b;
}


app.post('/soma', (req, res) => {
  const { a, b } = req.body;
  console.log('Dados recebidos:', req.body);
  const resultado = soma(a, b);
  res.send(`O resultado da soma de ${a} e ${b} é ${resultado}`);
});


app.post('/subtracao', (req, res) => {
  const { a, b } = req.body;
  const resultado = subtracao(a, b);
  res.send(`O resultado da subtração de ${a} e ${b} é ${resultado}`);
});


app.post('/multiplicacao', (req, res) => {
  const { a, b } = req.body;
  const resultado = multiplicacao(a, b);
  res.send(`O resultado da multiplicação de ${a} e ${b} é ${resultado}`);
});


app.post('/divisao', (req, res) => {
  const { a, b } = req.body;
  if (b === 0) {
    res.send('Erro: divisão por zero não é permitida.');
  } else {
    const resultado = divisao(a, b);
    res.send(`O resultado da divisão de ${a} por ${b} é ${resultado}`);
  }
});


const port = 3001;
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
